#pragma once

using int8_t = char;
using int16_t = short;
using int32_t = int;

using uint8_t = unsigned char;
using uint16_t = unsigned short;
using uint32_t = unsigned int;
