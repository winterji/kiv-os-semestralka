#include <stdstring.h>
#include <stdfile.h>
#include <stdmutex.h>

#include <drivers/gpio.h>
#include <drivers/i2c_slave.h>

/**
 * Hello task - blicks LED on GPIO pin 47 and writes hello message to uart
 * 
 * Ceka na stisk tlacitka, po stisku vyblika LEDkou "SOS" signal
 **/

constexpr uint32_t symbol_tick_delay = 0x400;
constexpr uint32_t char_tick_delay = 0x1000;

uint32_t log_fd, slave;

const float random_values[] = {
    1.1f, 2.2f, 3.3f, 4.4f, 5.5f, 6.6f, 7.7f, 8.8f,
};
const uint32_t random_values_len = 8;

void prep_msg(char* buff, const char* msg) {
    strncpy(buff, "SLAVE: ", 7);
    strncpy(buff + 7, msg, strlen(msg));
}

void log(const char* msg)
{
    char new_buff[strlen(msg) + 7];
    prep_msg(new_buff, msg);
    write(log_fd, new_buff, strlen(msg)+7);
}

void log(const uint32_t value) {
    char buff[32], pom[32];
    itoa(value, pom, 10);
    prep_msg(buff, pom);
    write(log_fd, buff, strlen(buff));
}

void send_value(const float value) {
    char pom[5], buff[32];
    bzero(pom, 5);
    bzero(buff, 32);
    strncpy(buff, "Sending: ", 15);
    ftoa(value, pom, 1);
    concat(buff, pom);
    concat(buff, "\n");
    log(buff);
    write(slave, pom, 5);
}

// void blink()
// {
// 	write(led, "1", 1);
// 	sleep(0x1000);
// 	write(led, "0", 1);
// }

// void get_random(char* buff)
// {
//     read(trng, buff, 4);
// }

// void do_cycle_random() {
//     char buff[4], temp_buff[32]; // buffer nulled
//     uint32_t* wbuf;
//     int rndNum;

//     write(uart, "Random number: ", 15);
//     blink();
//     get_random(buff);
//     wbuf = reinterpret_cast<uint32_t*>(buff);
//     rndNum = wbuf[0];
//     itoa(rndNum, temp_buff, 10);
//     write(uart, temp_buff, strlen(temp_buff));
// }

int main(int argc, char** argv)
{
    uint32_t counter = 0;
    char buff[32];
    bzero(buff, 32);

    log_fd = pipe("log", 128);

    log("Slave task started\n");

    // start i2c connection
    slave = open("DEV:i2c/2", NFile_Open_Mode::Read_Write);
    if (slave == Invalid_Handle) {
        log("Error opening I2C slave connection\n");
        return 1;
    }
    // set addresses
    TI2C_IOCtl_Params params;
    params.address = 2;
    params.targetAdress = 1;
    ioctl(slave, NIOCtl_Operation::Set_Params, &params);
    log("I2C connection slave started...\n");

    // sleep(0x100);
    // TI2C_IOCtl_Params params2;
    // ioctl(slave, NIOCtl_Operation::Get_Params, &params2);
    // char buff2[32];
    // itoa(params2.address, buff2, 10);
    // concat(buff2, " addr\n");
    // log(buff2);

    // sleep(0x100);
    // bzero(buff, 32);
    // read(slave, buff, 32);
    // log(buff);

    for (;;) {
        // log("trying to send random value\n");
        send_value(random_values[counter]);
        counter = (counter + 1) % random_values_len;
        // log("Data sent from slave\n");
        sleep(0x15000);
    }

    close(slave);
    log("Open files closed in slave\n");
    close(log_fd);

    return 0;
}
