#include <stdstring.h>
#include <stdfile.h>
#include <stdmutex.h>

#include <drivers/gpio.h>
#include <drivers/i2c_master.h>

/**
 * Hello task - blicks LED on GPIO pin 47 and writes hello message to uart
 * 
 * Ceka na stisk tlacitka, po stisku vyblika LEDkou "SOS" signal
 **/

uint32_t master, log_fd;

float received_values[32];
uint32_t received_values_len = 0;

void log(const char* msg)
{
    char new_buff[strlen(msg) + 8];
    strncpy(new_buff, "MASTER: ", 8);
    strncpy(new_buff + 8, msg, strlen(msg));
    write(log_fd, new_buff, strlen(msg) + 8);
}

int main(int argc, char** argv)
{
    char buff[9], msg[32];
    uint32_t slave_input;

    log_fd = pipe("log", 128);
    // trng = open("DEV:trng/0", NFile_Open_Mode::Read_Write);

    log("Master task started\n");

    // start i2c connection
    master = open("DEV:i2c/1", NFile_Open_Mode::Read_Write);
    if (master == Invalid_Handle) {
        log("Error opening I2C master connection\n");
        return 1;
    }
    // set addresses
    TI2C_IOCtl_Params params;
    params.address = 1;
    params.targetAdress = 2;
    ioctl(master, NIOCtl_Operation::Set_Params, &params);
    log("I2C connection master started...\n");

    // TI2C_IOCtl_Params params2;
    // ioctl(master, NIOCtl_Operation::Get_Params, &params2);
    // char buff2[32];
    // itoa(params2.targetAdress, buff2, 10);
    // concat(buff2, " addr\n");
    // log(buff2);
    sleep(0x100);
    for (;;) {
        bzero(msg, 32);
        bzero(buff, 9);
        read(master, buff, 5);
        slave_input = atoi(buff);
        received_values[received_values_len++] = slave_input;

        strncpy(msg, "Received: ", 10);
        concat(msg, buff);
        concat(msg, "\n");
        log(msg);
        // log("Data sent from master\n");
        sleep(0x15000);
    }

    close(master);
    log("Open files closed in master\n");
    close(log_fd);

    return 0;
}
