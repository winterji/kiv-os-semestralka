cd sources/userspace
./build.sh
cd ..
./build.sh
echo "Build directory rebuilt"