cd sources
./build.sh
cd userspace
./build.sh
cd ..
./build.sh
echo "Build directory rebuilt"